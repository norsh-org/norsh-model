package org.norsh.model.dtos.elements;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import org.norsh.config.NorshConstants;
import org.norsh.exceptions.ValidationException;
import org.norsh.model.dtos.crypto.CryptoSignedAbstractDto;
import org.norsh.model.types.ElementType;
import org.norsh.security.Hasher;
import org.norsh.util.Converter;
import org.norsh.util.Strings;

import lombok.Getter;
import lombok.Setter;

/**
 * DTO for creating an Element.
 * <p>
 * This class ensures the integrity and correctness of Element creation requests by validating essential fields such as
 * owner, type, symbol, decimals, nonce, public key and cryptographic signature.
 * </p>
 *
 * <h2>Special Cases:</h2>
 * <ul>
 * <li>If {@link #type} is {@link ElementType#PROXY}, the {@link #symbol} must end with '{@value NorshConstants#PROXY_SUFFIX}'.</li>
 * </ul>
 *
 * <h2>Example Usage:</h2>
 * <pre>
 * ElementCreateDto element = new ElementCreateDto();
 * element.setOwner("123abc...");
 * element.setType(ElementType.COIN);
 * element.setSymbol("NSH");
 * element.setDecimals(6);
 * element.setPublicKey("BASE64_ENCODED_PUBLIC_KEY");
 * element.setSignature("HEX_SIGNATURE");
 * element.validate();
 * </pre>
 *
 * @since 1.0.0
 * @version 1.0.0
 * @author Danthur Lice
 * @see ElementType
 * @see <a href="https://docs.norsh.org">Norsh Documentation</a>
 */
@Getter
@Setter
public class ElementCreateDto extends CryptoSignedAbstractDto {
    /** Owner of the Element. Cannot be null and must match the SHA3 hash of the public key. */
    private String owner;

    /** Type of the Element. Cannot be null and must correspond to a valid {@link ElementType}. */
    private ElementType type;

    /** Token symbol. Cannot be null and must contain 2 to 8 uppercase letters (A-Z). */
    private String symbol;

    /** Number of decimals. Cannot be null and must be between 0 and 18. */
    private Integer decimals;
    
    /** Number of tokens. Cannot be null and must be between 1 and 1,000,000,000 (1 bi) */
    private Integer supply;
    
    /**
     * Validates the fields of the ElementCreateDto based on predefined business rules.
     *
     * <h2>Validation Process:</h2>
     * <ul>
     * <li>Ensures that the public key is present and properly formatted.</li>
     * <li>Verifies that the owner matches the SHA3 hash of the provided public key.</li>
     * <li>Validates type, symbol, decimals, and nonce constraints.</li>
     * <li>Ensures that Proxy Elements have the correct symbol suffix.</li>
     * <li>Generates a hash to verify data integrity.</li>
     * <li>Performs cryptographic signature validation.</li>
     * </ul>
     *
     * @throws ValidationException if any validation rule is violated.
     */
    public void validate() throws ValidationException {
        List<String> details = new LinkedList<>();

        // Validate Public Key
        if (getPublicKey() == null || getPublicKey().isBlank() || !Converter.isBase64OrHex(getPublicKey())) {
            details.add("Invalid public key: The 'publicKey' field is required, cannot be null, and must be in Base64 or Hex format.");
        }

        byte[] publicKeyByte = Converter.base64OrHexToBytes(getPublicKey());

        // Validate Owner
        if (!Hasher.sha3Hex(publicKeyByte).equals(owner)) {
            details.add("Invalid owner: The 'owner' field is required, cannot be null, and must match the SHA3 hash of the provided public key.");
        }

        // Validate Proxy Symbol
        if (type == ElementType.PROXY) {
            if (symbol == null || symbol.isBlank() || !Pattern.matches("^[A-Z]{2,8}(" + NorshConstants.PROXY_SUFFIX + ")$", symbol)) {
                details.add(String.format("Invalid 'symbol' for Proxy Element: The 'symbol' is required, must contain 2 to 8 uppercase letters (A-Z), and must end with '%s'.", NorshConstants.PROXY_SUFFIX));
            }
        } else if (symbol == null || symbol.isBlank() || !Pattern.matches("^[A-Z]{2,8}$", symbol)) {
            details.add("Invalid symbol: The 'symbol' field is required, cannot be null, and must contain 2 to 8 uppercase letters (A-Z).");
        }

        // Validate Decimals
        if (decimals == null || decimals < 0 || decimals > 18) {
            details.add("Invalid decimals: The 'decimals' field is required, cannot be null, and must be between 0 and 18.");
        }
        
        // Validate supply
        if (supply == null || supply < 1 || supply > 1_000_000_000) {
            details.add("Invalid supply: The 'supply' field is required, cannot be null, and must be between 1 and 1,000,000,000.");
        }

        super.validate(details);

        // Generate hash for integrity verification
        this.setHash(Hasher.sha256Hex(Strings.concatenate(owner, symbol, decimals, supply)));

        // Perform cryptographic signature validation
        super.validate();
    }
}

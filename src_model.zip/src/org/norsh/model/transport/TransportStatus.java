package org.norsh.model.transport;

/**
 * Enum representing the status of a request in the Norsh ecosystem.
 * <p>
 * This enum defines different states a request can be in, allowing structured 
 * handling of various processing outcomes.
 * </p>
 *
 * <h2>Statuses:</h2>
 * <ul>
 *   <li>{@link #CREATED} - The request is currently being processed.</li>
 *   <li>{@link #DONE} - The request has been successfully completed.</li>
 *   <li>{@link #NOT_FOUND} - The requested item does not exist.</li>
 *   <li>{@link #TIMEOUT} - The request exceeded the allowed processing time.</li>
 *   <li>{@link #ERROR} - The request encountered an error during processing.</li>
 *   <li>{@link #INSUFFICIENT_BALANCE} - The request failed due to insufficient balance (HTTP 402).</li>
 * </ul>
 *
 * @since 1.0.0
 * @version 1.0.0
 * @author Danthur Lice
 * @see <a href="https://docs.norsh.org">Norsh Documentation</a>
 */
public enum TransportStatus {
	/** The request is currently being processed. */
    CREATED("The request is being processed."),

    /** The requested item does not exist in the system. */
    NOT_FOUND("The requested item does not exist."),

    /** The request timed out before completion. */
    TIMEOUT("The request timed out."),

    /** The request encountered an error during processing. */
    ERROR("An error occurred while processing the request."),

    /** The request failed due to insufficient balance to complete the transaction. */
    INSUFFICIENT_BALANCE("Insufficient balance to process the request."),
	
    FORBIDDEN("you not authorized"),
	
    /** The request has been successfully completed. */
    DONE("The request has been completed successfully.");


    private final String description;

    TransportStatus(String description) {
        this.description = description;
    }

    /**
     * Retrieves the description of the status.
     *
     * @return A string description of the status.
     */
    public String getDescription() {
        return description;
    }
}

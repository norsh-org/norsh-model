package org.norsh.model.transport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO representing the status of a request in the Norsh ecosystem.
 * <p>
 * This class encapsulates the request ID, its status, and optional response data.
 * </p>
 *
 * <h2>Fields:</h2>
 * <ul>
 *   <li>{@link #requestId} - Unique identifier of the request.</li>
 *   <li>{@link #status} - The current status of the request.</li>
 *   <li>{@link #requestData} - Optional data related to the request response.</li>
 * </ul>
 *
 * @since 1.0.0
 * @version 1.0.0
 * @author Danthur Lice
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class Transport {
    /** Unique identifier of the request. */
    private String requestId;
    
    private RestMethod method;
    
    private Object requestData;
    
    private String requestClassName;
    
    private Object responseData;
    
    private String responseClassName;
    
    /** The current status of the request. */
    private TransportStatus status;
    
    
    
    
//    /**
//     * Constructs a {@link TransportDtos} with only request ID and status.
//     *
//     * @param request The unique request identifier.
//     * @param status    The status of the request.
//     */
//    public TransportDtos(String request, TransportStatus status) {
//        this.requestId = request;
//        this.status = status;
//    }
//
//    /**
//     * Constructs a {@link TransportDtos} with request ID and data.
//     * <p>
//     * Automatically sets the status to {@link TransportStatus#DONE}.
//     * </p>
//     *
//     * @param request The unique request identifier.
//     * @param data      The response data.
//     */
//    public TransportDtos(String request, Object data) {
//        this.requestId = request;
//        this.status = TransportStatus.DONE;
//        this.requestData = data;
//    }

    /**
     * Converts this DTO to a response format by removing internal fields 
     * that should not be exposed in API responses.
     *
     * @return A new {@link Transport} instance without the `className` field.
     */
    public Transport toResponse() {
    	Transport response = new Transport(this.requestId, this.status);
        return response;
    }

	public Transport(String requestId, RestMethod method, Object requestData) {
		this.requestId = requestId;
		this.method = method;
		this.requestData = requestData;
		this.requestClassName = requestData.getClass().getCanonicalName();
		this.status = TransportStatus.CREATED;
	}

	public Transport(String requestId, TransportStatus status) {
		this.requestId = requestId;
		this.status = status;
	}
	
	public Transport(String requestId, TransportStatus status, Object responseData) {
		this.requestId = requestId;
		this.status = status;
		if (responseData != null) {
			this.setResponseData(responseData);
			this.setResponseClassName(responseData.getClass().getCanonicalName());
		}
	}
}

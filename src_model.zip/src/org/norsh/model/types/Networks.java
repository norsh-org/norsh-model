package org.norsh.model.types;

public enum Networks {
	ETHEREUM
}
